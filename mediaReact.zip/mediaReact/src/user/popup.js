import React from 'react'

function popup() {
  return (
    <div>popup</div>
  )
}

export default popup