import React from 'react'
import Usersidebar from './usersidebar'
import Footer from './Footer'
function search() {
  return (
    <div class="work_user">
        <div class="row">
        < Usersidebar/>
    <div className='body-m-user'>
        <section className='head-1-user'>
        <section class="hero">
<div class="hero__slider_user owl-carousel_user">
<div class=" search_user">
    <div className='row'>
    <div className='col-1 searchcol_user'>
        <i class="fa-sharp fa-solid fa-magnifying-glass fa-flip-horizontal magnifying_user" ></i>
        </div>
        <div className='col-10 searchcol_user'>
        <input type="text" className="searchbar_user" name="fname"></input>
        </div>
        </div>
    

</div>
</div>
</section>

        </section>
    <section class="work_user">
    <div className='Wording_user searchhead_user'>
       Videos
    </div>
    <div className=' grid_1_user'>
        {/* <div className="scroll__container"> */}
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u  work__item_user">
                <img src="img/work/work-1.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/1542216179.svg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/work/work-7.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/work/work-3.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/work/work-6.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/work/work-5.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/work/work-1.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/work/work-7.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/work/work-5.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/work/work-6.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/work/work-3.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/1542216179.svg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/work/work-5.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
           
        {/* <div className="scroll__container"> */}
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/work/work-1.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/1542216179.svg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/work/work-7.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/work/work-3.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/work/work-6.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/work/work-5.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/work/work-1.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/work/work-7.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/work/work-5.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/work/work-6.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/work/work-3.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/1542216179.svg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
            <div class="col-lg-2 col-md-2 col-sm-2 col-2 wo_u work__item_user">
                <img src="img/work/work-5.jpg" class="im_u" alt="Responsive image" />
                <div class="work__item__hover_user">
                    <h4>VIP Auto Tires & Service</h4>
                    <ul>
                        <li>eCommerce</li>
                        <li>Magento</li>
                    </ul>
                </div>
            </div>
        {/* </div> */}
    
        {/* </div> */}
    </div>
</section>
<Footer/>
</div>
</div>
            </div>
  )
}

export default search