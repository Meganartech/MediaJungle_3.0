import React from 'react'

function Footer() {
  return (
    <div className='row footer_user'>
    <table>
        <thead>
            <th>Company</th>
            <th>About us</th>
            <th>Need Help?</th>
            <th>Connect us</th>
        </thead>
        <tbody>
            <tr>
            <td>Target</td>
            <td>A vision statement</td>
            <td>Help Center</td>
            <td>Location</td>
            </tr>
            <tr>
            <td>History</td>
            <td></td>
            <td>Customers</td>
            <td>Robert,12 Bobcat Lane,</td>
            </tr>
            <tr>
            <td>Vision</td>
            <td></td>
            <td>Security</td>
            <td> St. Robert, MO 65584</td>
            
            </tr>

        </tbody>
    </table>

</div>
  )
}

export default Footer